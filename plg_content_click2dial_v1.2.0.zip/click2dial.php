<?php
/**
 * Click2Dial Content Plugin
 * 
 * @package		Joomla.Plugin
 * @subpackage	Content.click2dial
 * @since		3.0
 */
defined ( '_JEXEC' ) or die ();

jimport ( 'joomla.plugin.plugin' );

class plgContentClick2dial extends JPlugin
{
	function plgContentClick2dial( &$subject, $params )
	{
		parent::__construct ( $subject, $params );
	}

	public function onContentPrepare($context, &$row, &$params, $page = 0)
	{
		// Do not run this plugin when the content is being indexed
		if ($context == 'com_finder.indexer')
		{
			return true;
		}
		
		if (is_object($row))
		{
			return $this->click2Dial($row->text, $params);
		}
		return $this->click2Dial($row, $params);
	}
	
	protected function click2Dial(&$text, &$params)
	{
		$phoneDigits1a 		= $this->params->get('phoneDigits1a', 4);
		$phoneDigits2a 		= $this->params->get('phoneDigits2a', 4);
		$phoneDigits1b 		= $this->params->get('phoneDigits1b', 3);
		$phoneDigits2b 		= $this->params->get('phoneDigits2b', 4);
		$phone_icon1disable = $this->params->get('phone_icon1disable', "1");
		$phone_icon2disable = $this->params->get('phone_icon2disable', "1");
		$phone_icon1		= $this->params->get('phone_icon1', "icon-home");
		$phone_icon2		= $this->params->get('phone_icon2', "icon-mobile");
		$badge_tag1			= $this->params->get('badge_tag1', "");
		$badge_tag2			= $this->params->get('badge_tag2', "");
		
		// matches 4 numbers followed by an optional hyphen or space,
		// then followed by 4 numbers.
		// phone munber is in the form XXXX-XXXX or XXXX XXXX
		$pattern1 	  = '/(\W[0-9]{'.$phoneDigits1a.'})-? ?(\W[0-9]{'.$phoneDigits2a.'})/';
		$pattern2	  = '/(\W[0-9]{'.$phoneDigits1b.'})-? ?(\W[0-9]{'.$phoneDigits2b.'})/';
		$icon1path	  = '&nbsp;<i class="'.$phone_icon1.'"></i>';
		$icon2path	  = '&nbsp;<i class="'.$phone_icon2.'"></i>';
		$replacement1 = '&nbsp;<a href="tel:$1$2"><span class="badge '.$badge_tag1.'">
						$1$2</span></a>';
		$replacement2 = '&nbsp;<a href="tel:$1$2"><span class="badge '.$badge_tag2.'">
						$1$2</span></a>';
		
		if ($phone_icon1disable)
		{
			$replacement1 = $icon1path.$replacement1;
		}
		if ($phone_icon2disable)
		{
			$replacement2 = $icon2path.$replacement2;
		}
		
		$text = preg_replace($pattern1, $replacement1, $text);
		$text = preg_replace($pattern2, $replacement2, $text);
		
		return true;
	}
}

	